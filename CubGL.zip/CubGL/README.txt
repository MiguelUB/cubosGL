Cub en OpenGL sense display lists rotant amb un timer.

